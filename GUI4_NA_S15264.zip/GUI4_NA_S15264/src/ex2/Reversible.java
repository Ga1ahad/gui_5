package ex2;

public interface Reversible {
	Reversible reverse();



}
